import App from './navigation/MainTabNavigator';
export default App;
