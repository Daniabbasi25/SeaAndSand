import FlexibleTabBarComponent from './FlexibleTabBarComponent';
import withCustomStyle from './withCustomStyle';

export {
  FlexibleTabBarComponent,
  withCustomStyle,
}
